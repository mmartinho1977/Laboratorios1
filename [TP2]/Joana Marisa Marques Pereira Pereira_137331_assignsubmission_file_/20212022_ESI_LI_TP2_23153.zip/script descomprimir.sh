#!/bin/bash

rm -r Videoteca/ #Eliminar direotoria Videoteca
unzip Videoteca.zip #Descompacta o arquivo zip

#Para executar a scrip é necessário na linha de comandos utilizar o seguinte comando: sh ~/Desktop/script.sh
