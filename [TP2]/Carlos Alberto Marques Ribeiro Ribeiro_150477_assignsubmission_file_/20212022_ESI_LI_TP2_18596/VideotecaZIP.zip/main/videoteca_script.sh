#! /bin/bash

################################## MENU PRINCIPAL, SELECÇÂO DE OPÇÔES
menu () {

while true
do
	clear
	echo " "
	echo "              ************************************"
	echo "              *  $(tput bold)Bem vindo á Videoteca$(tput sgr0) - a18596  *" 
	echo "              ************************************"
	echo " "
	echo " "
	echo "Seleccione a opção pretendida "
	echo " "
	echo "Opção 1 - Listar Filmes."
	echo "Opção 2 - Adicionar Filme."
	echo "Opção 3 - Apagar Filme."
	echo "Opção 4 - Editar Filme."
	echo "Opção 5 - Apagar Categoria."
	echo "Opção 6 - Editar Categoria."
	echo "Opção 0 - SAIR."
	echo " "

	read -p "Insira a sua opção: " OPCAO

	case $OPCAO in
		1) FUNCTION_LIST_FILMES_MENU;;
		2) FUNCTION_ADD_FILMES;;
		3) FUNCTION_DEL_FILMES;;
		4) FUNCTION_EDIT_FILMES;;
		5) FUNCTION_DEL_CATEG;;
		6) FUNCTION_EDIT_CATEG;;
		0) clear;exit;;
		*) menu
	esac

done

}

################################## SELECÇÂO DE LISTAGEM DE FILME/CONTEUDO
FUNCTION_LIST_FILMES_MENU () {

		clear
		echo ""
		echo " * Lista Filmes *"
		echo ""
		tree ./VIDEOTECA/ | more
		echo ""
		echo ""

		echo "Escreva o nome do Filme para listar conteudo /" 
		read -p "Ou digite (s) para voltar menu principal: " LISTFILM
		echo ""

		case $LISTFILM in
			[s/S] ) menu;;
				* ) FUNCTION_LIST_FILMES;;
		esac
}

FUNCTION_LIST_FILMES () {

		find ./* -iname "review_$LISTFILM.txt" > ./tempfile1
		output=$(awk "NR==1" ./tempfile1)
		
		if [ -s "$output" ];
		then
			clear
			echo "            *** Informação do Filme $LISTFILM ***"
			echo ""
			cat "$output" | more
			echo ""
			echo ""
			read -p "Deseja voltar menu principal s/n: " LISTCLEAR
		
			case $LISTCLEAR in
				[sS]* ) rm ./tempfile1;menu;;
				[nN]* )	rm ./tempfile1;clear;exit;;
			    	* ) FUNCTION_LIST_FILMES;;
			esac
		else
			echo ""
			echo "$(tput bold)Filme não disponivel!$(tput sgr0)"
			read -p "Enter para continuar"
			FUNCTION_LIST_FILMES_MENU
		fi
}

################################## FUNÇÂO PARA ADICIONAR NOVOS FILMES/DIRETORIAS
FUNCTION_ADD_FILMES () {

	clear
	echo " "
	echo " * Adicionar Filme *"
	echo ""
	read -p "Indique o nome do Filme: " NOMEFILME
	read -p "Adicione categoria do Filme: " GENEROFILME
		mkdir -p ./VIDEOTECA/"$GENEROFILME"/"$NOMEFILME"
		touch ./VIDEOTECA/"$GENEROFILME"/"$NOMEFILME"/review_"$NOMEFILME".txt

	echo "Adicione informação do Filme: "
	echo " "
	echo "         $(tput bold)NOTA:$(tput sgr0) Após terminar de inserir, permir  $(tput bold)ctl*d$(tput sgr0)"	
	echo " "	
		cat > ./VIDEOTECA/"$GENEROFILME"/"$NOMEFILME"/review_"$NOMEFILME".txt 

	echo " "
	echo "Filme $(tput bold)"$NOMEFILME", $(tput sgr0)criado com sucesso na videoteca, inserido na categoria $(tput bold)"$GENEROFILME".$(tput sgr0)"
	echo " "
	
	FUNCTION_REPLAY_ADD_FILMES
}

FUNCTION_REPLAY_ADD_FILMES () {

	while true
	do
	read -p "Adiconar novo filme s/n: " REPLAYADDFILME
	case $REPLAYADDFILME in
			[sS]* ) FUNCTION_ADD_FILMES;;
			[nN]* )	menu;;
			    * ) FUNCTION_REPLAY_ADD_FILMES;;
	esac
	done
}

################################## FUNÇÂO PARA ELIMINAR FILMES
FUNCTION_DEL_FILMES () {

	clear
	echo ""
	echo " * Lista Filmes *"
	echo ""

	cd ./VIDEOTECA 
	ls */ > tempfile
	cat tempfile

	echo ""
	read -p "Indique a categoria que o filme está inserido: " CATFILME

	if [ -d "$CATFILME" ]; 
	then
		cd ./"$CATFILME"
		ls  > ../tempfile2
		echo ""
		cat ../tempfile2 | more

		echo ""
		read -p "Insira o nome do Filme a remover: " DELFILME 

			if [ -d "$DELFILME" ];
			then
				rm -r "$DELFILME"
		
				echo ""
				echo "Filme $(tput bold)"$DELFILME" $(tput sgr0)removido com sucesso!"
				echo ""
	
				cd ../
				rm tempfile
				rm tempfile2
				cd ../

				FUNCTION_REPLAY_DEL_FILMES
			else
				echo ""
				echo "$(tput bold)Filme não disponivel!$(tput sgr0)"
				read -p "Enter para continuar"

				cd ../
				rm tempfile
				rm tempfile2
				cd ../

				FUNCTION_DEL_FILMES
			fi	
	else
		echo ""
		echo "$(tput bold)Categoria não disponivel!$(tput sgr0)"
		read -p "Enter para continuar"
		rm tempfile
		cd ..
		FUNCTION_DEL_FILMES

	fi
	

}

FUNCTION_REPLAY_DEL_FILMES () {

	read -p "Deseja remover outro filme (y/n): " REPLAY_DEL_FILME

	case $REPLAY_DEL_FILME in
		[yY] ) FUNCTION_DEL_FILMES;;
		[nN] ) menu;;
			*) FUNCTION_REPLAY_DEL_FILMES;;
	esac
	
}

################################## FUNÇÂO PARA EDITAR FILMES/CONTEUDOS
FUNCTION_EDIT_FILMES () {
	
	clear
	echo ""
	echo " * Lista Filmes *"
	echo ""

	tree ./VIDEOTECA/ | more

	echo ""
	echo "1) Editar conteudo do Filme."
	echo "2) Editar nome do Filme."
	echo "3) Trocar categoria Filme."
	echo "3) Voltar ao Menu principal."
	echo ""
	read -p "Escolha uma das opções: " FILME_OPTION

	case $FILME_OPTION in

		[1] ) FUNCTION_EDIT_CONT_FILME;;
		[2] ) FUNCTION_EDIT_NOME_FILM;;
		[3] ) FUNCTION_EDIT_FILME_CATEG;;
		[4] ) menu;;
		  * ) FUNCTION_EDIT_FILMES;;

	esac

	
}

FUNCTION_EDIT_CONT_FILME () {

	clear
	echo ""
	echo " * Lista Filmes *"
	echo ""

	tree ./VIDEOTECA/ | more
	cd ./VIDEOTECA

	echo ""
	read -p "Indique o nome do filme a editar: " EDITFILME 
	
	TEMPEDITFILME="$EDITFILME"

	find ./* -iname "review_$TEMPEDITFILME.txt" >> ../tempfile5
	output_tempfile=../tempfile5

	if [ -s "$output_tempfile" ];
	then
		output3=$(awk "NR==1" ../tempfile5)

		nano "$output3"

		rm ../tempfile5
			
		cd ..
		
		echo ""
		echo "Filme $(tput bold)"$TEMPEDITFILME", $(tput sgr0)editado com sucesso."
		
		FUNCTION_REPLAY_EDIT_FILMES

	else
		echo ""
			echo "$(tput bold)Filme não disponivel!$(tput sgr0)"
			rm ../tempfile5
			cd ..
			read -p "Enter para continuar"
			FUNCTION_EDIT_CONT_FILME
	fi

	FUNCTION_REPLAY_EDIT_FILMES
}


FUNCTION_EDIT_NOME_FILM () {

	clear
	echo ""
	echo " * Lista Filmes *"
	echo ""

	tree ./VIDEOTECA/ | more
	
	cd ./VIDEOTECA

	echo ""
	read -p "Indique o nome do filme a editar: " OLDFILME 
	
	find ./* -iname "$OLDFILME" > ../tempfile3
	find ./* -iname "review_$OLDFILME.txt" >> ../tempfile3
	output_tempfile=../tempfile3

	if [ -s "$output_tempfile" ];
	then
		read -p "Indique novo nome do filme: " NEWFILME
		cp ../tempfile3 ../tempfile4
		replace "$OLDFILME" "$NEWFILME" -- ../tempfile4

		output2=$(awk "NR==2" ../tempfile3)
		output1=$(awk "NR==1" ../tempfile3)
		outputnew2=$(awk "NR==2" ../tempfile4)
		outputnew1=$(awk "NR==1" ../tempfile4)

		mkdir "$outputnew1"
		mv "$output2" "$outputnew2"
		rm -d "$output1"
	
		rm ../tempfile3
		rm ../tempfile4
	
		cd ..
		
		echo ""
		echo "Filme $(tput bold)"$OLDFILME", $(tput sgr0)editado para $(tput bold)"$NEWFILME"$(tput sgr0)."
		
		FUNCTION_REPLAY_EDIT_FILMES

	else
		echo ""
		echo "$(tput bold)Filme não disponivel!$(tput sgr0)"
		rm ../tempfile3
		cd ..
		read -p "Enter para continuar"
		FUNCTION_EDIT_NOME_FILM
	fi

}

FUNCTION_EDIT_FILME_CATEG () {

	clear
	echo ""
	echo " * Lista Filmes *"
	echo ""

	tree ./VIDEOTECA/ | more
	
	cd ./VIDEOTECA

	echo ""
	read -p "Indique o nome do filme a mudar de categoria: " CHANGEFILMECAT 
	
	find ./* -iname "$CHANGEFILMECAT" > ../tempfile6
	output_tempfile6=../tempfile6

	if [ -s "$output_tempfile6" ];
	then
		output6=$(awk "NR==1" ../tempfile6)
		cd "$output6"
		cd ../..

		read -p "Indique nova categoria do Filme: " CHANGEFILME_NEWCAT

		if [ -d "$CHANGEFILME_NEWCAT" ];
		then	
			mv -i "$output6" "$CHANGEFILME_NEWCAT"
			rm ../tempfile6
			
		else
			mkdir "$CHANGEFILME_NEWCAT"
			mv -i "$output6" "$CHANGEFILME_NEWCAT"
			rm ../tempfile6

		fi

		cd ..
		echo ""
		echo "Filme $(tput bold)"$CHANGEFILMECAT", $(tput sgr0)movido para a categoria $(tput bold)"$CHANGEFILME_NEWCAT"$(tput sgr0)."

		FUNCTION_REPLAY_EDIT_FILMES

	else
		echo ""
		echo "$(tput bold)Filme não disponivel!$(tput sgr0)"
		rm ../tempfile6
		cd ..
		read -p "Enter para continuar"
		FUNCTION_EDIT_FILMES
	fi


}

FUNCTION_REPLAY_EDIT_FILMES () {

	echo ""
	read -p "Deseja editar outro filme (y/n): " REPLAY_EDIT_FILME

	case $REPLAY_EDIT_FILME in
		[yY] ) FUNCTION_EDIT_FILMES;;
		[nN] ) menu;;
			*) FUNCTION_REPLAY_EDIT_FILMES;;
	esac

}

################################## FUNÇÂO PARA APAGAR CATEGORIA
FUNCTION_DEL_CATEG () {

	clear
	echo ""
	echo " * Lista Categorias *"
	echo ""
	cd ./VIDEOTECA
	ls

	echo ""
	echo ""
	read -p "Insira o nome Categoria a remover: " REMOVE_CAT
	echo ""
	echo ""
	
	if [ -d "$REMOVE_CAT" ];
	then
		if [ "$(ls -A "$REMOVE_CAT")" ];
		then
			echo "A Categoria $(tput bold)"$REMOVE_CAT" $(tput sgr0), contêm filmes,"
			echo "Não pode ser eliminada."
			echo ""
			echo "1) Voltar Menu Principal"
			echo "2) Eliminar Filme"
			echo "3) Sair"
			echo ""
			read -p "Seleccione uma das seguintes opções: " REMOVE_CAT_OPTION
			echo ""
			
			cd ../

			FUNCTION_DEL_CAT_OPTION
			

		else
			rm -d "$REMOVE_CAT"
			echo ""
			echo "Categoria $(tput bold)"$REMOVE_CAT", $(tput sgr0)removido com sucesso."
			cd ../
			echo ""
			read -p "Enter para continuar"
		fi	
	else 
		echo "$(tput bold)Categoria não encontrada!$(tput sgr0)"
		read -p "Enter para continuar"
		cd ..
		FUNCTION_DEL_CATEG
	fi


}

FUNCTION_DEL_CAT_OPTION () {

	case $REMOVE_CAT_OPTION in
		[1] ) menu;;
		[2] ) FUNCTION_DEL_FILMES;;
		[3] ) exit;;
		  * ) FUNCTION_DEL_CAT_OPTION;;
	esac

}

################################## FUNÇÂO PARA EDITAR CATEGORIA
FUNCTION_EDIT_CATEG () {

	clear
	cd ./VIDEOTECA
	echo ""
	echo " * Lista Categorias *"
	echo ""
	ls 
	echo ""
	read -p "Insira o nome da categoria a editar: " OLDCAT

	if [ -d $OLDCAT ];
	then
		read -p "Novo nome da categoria: " NEWCAT

		mv -i ./"$OLDCAT" ./"$NEWCAT"

		echo ""
		echo "Categoria $(tput bold)$OLDCAT, $(tput sgr0)editada para $(tput bold)$NEWCAT$(tput sgr0)." 
		echo ""

		cd ../

		FUNCTION_REPLAY_EDIT_CAT

	else
		echo ""
		echo "$(tput bold)Categoria não encontrada!$(tput sgr0)"
		read -p "Enter para continuar"
		cd ..
		FUNCTION_EDIT_CATEG

	fi
}

FUNCTION_REPLAY_EDIT_CAT () {

	echo ""
	read -p "Deseja editar outra categoria s/n: " REPLAY_NEWCAT

	case $REPLAY_NEWCAT in
		[s/S] ) FUNCTION_EDIT_CATEG;;
		[n/N] ) menu;;
			* ) FUNCTION_REPLAY_EDIT_CAT 
	esac

}

menu