# make_videoclube.sh  

#### É responsavel pela criação do videoclube.  
#### Este permite a criação do mesmo em formato normal ou em formato comprimido(zip).  

# browse_videoclube.sh  

#### Este ficheiro permite a pesquisa pelo videoclube  
#### Caso selecione a opção de formato normal com o "make_videoclube.sh" este correrá automaticamente
#### Uma cópia do mesmo é colocada dentro da pasta videoclube criada (em qualquer uma das versões), caso pretenda correr futuramente

# Erros de permissões  

### Caso tenha algum erro de permissões corra os seguintes comandos:  
#### $ chmod +x make_videoclube.sh  
#### $ chmod +x browse_videoclube.sh  


# Descompressão  

#### $ unzip videoclube.zip  
