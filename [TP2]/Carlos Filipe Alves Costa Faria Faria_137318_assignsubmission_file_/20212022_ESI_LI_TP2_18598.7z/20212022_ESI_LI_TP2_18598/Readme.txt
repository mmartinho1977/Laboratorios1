Funções do scrip a executar:
-Criação da pasta Videoteca e dentro dela as pastas: Horror,Action,Comedy,Romance;
-Criação dos ficheiro Plot.txt, Rating.txt, Cast.txt dentro da pasta de cada filme;
-Criação de uma copia, colocando assim este filme nas duas categorias;
-Mover pasta de diretorio;
-Criação do zip de toda a diretoria Videoteca;
-Efetuar o unzip para a pasta Videos;
-Criação de pasta Info, onde foram criados 2 ficheiros, um para contar o numero de pastas na diretoria e o outro para descobrir os filmes com cotação igual a 9;



Como utilizar a script:
Assumindo que o script se encontra no Desktop;
1ª - Abrir Terminal e escrever o seguinte comando "cd Desktop", acedendo assim ao Desktop;
2º - Escrever o seguinte comando "nano ScriptVideoteca.sh", acedendo assim ao ficheiro;
3º - Na linha 44 e 50, alterar o nome de utlizador(neste caso "filipefaria") para o da maquina local;
4º - Pressionar CRTL X seguido de Y para sair e gravar;
5º - Escrever o seguinte comando "bash ./ScriptVideoteca.sh;
4º - Videoteca criada com sucesso, de salientar que foi efetuado um unzip para a pasta Videos;



