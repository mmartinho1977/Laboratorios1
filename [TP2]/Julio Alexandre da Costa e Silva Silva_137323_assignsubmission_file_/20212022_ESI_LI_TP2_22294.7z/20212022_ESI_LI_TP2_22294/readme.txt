Instruções

1 - Deve ser executado o ficheiro videoteca, deve ser colocado na diretoria local do utilizador.
Cria todas as diretorias necessarias

2 - Usar o ficheiro compressão para fazer copia de segurança.

3 - Usar o ficheiro extrair se necessário repor cópia ou mover de computador.

Obrigado

Júlio Silva - 22294