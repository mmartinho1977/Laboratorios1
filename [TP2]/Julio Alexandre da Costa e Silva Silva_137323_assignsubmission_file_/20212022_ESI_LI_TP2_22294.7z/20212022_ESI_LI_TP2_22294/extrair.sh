echo "Benvindo ao programa de videoteca"
echo " "
echo "Aluno: Júlio Silva - 22294"
echo " "
echo " "
echo "Utilizador:" 
whoami
echo " "
date -u
echo " "
echo "Instalar o zip mais recente do Linux, caso não exista"
sudo apt install zip unzip  # instala o zip mais recente do Linux
unzip Backup.zip -d ~/video # descomprime o ficheiro videoteca.zip
echo "Extraido para a pasta video da pasta pessoal" #informa no ecra do sucesso!
echo "Fim da extração dos ficheiros"
echo "Fechar janela"

