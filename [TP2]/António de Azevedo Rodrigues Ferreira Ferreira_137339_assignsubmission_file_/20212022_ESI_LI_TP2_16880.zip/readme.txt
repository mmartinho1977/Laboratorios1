####### a16880@alunos.ipca.pt ####
####### Antonio Ferreira ##########
##README##
This can script can be executed anywhere on the host machine for it uses the HOME environment variable to create the folder structure and files

The script has a help function to facilitate usage, nevertheless that function can be summed up to this:

You have to use: [-l], [-h], [-d] and [-m]
	-l,           list folder structure and content of files inside the videoteca
	-h,           prints help information
	-d,           deletes videoteca
	-c,           creates videoteca

Examples:
./videoteca.sh -l (list all info on videoteca)


After creating the videoteca, any information that is added must be done manually, this script will only create a basic structure for the videoteca.
