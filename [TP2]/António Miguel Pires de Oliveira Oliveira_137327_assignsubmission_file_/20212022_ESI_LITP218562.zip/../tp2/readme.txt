Este projeto conciste no desenvilvimento de uma vidioteca ....

1- Em primeiro lugar é necessária a execução do segunte comando "chmod +x script-name.sh" em ambas as scrips.

2- Na script principal existe um menu bastante intuitivo onde é explicito como agir com o programa.

3- Quanto à script de comprimir e descomprimir foi decidido descomprimir para a pasta /home para evitar pastas de utilizadores que podem diferir.
