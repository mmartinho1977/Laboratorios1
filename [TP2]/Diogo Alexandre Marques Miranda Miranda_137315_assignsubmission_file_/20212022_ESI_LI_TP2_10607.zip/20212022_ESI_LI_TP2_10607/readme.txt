Para extrair e comprimir a videoteca basta correr o script createVideoteca10607.sh

Criar a videoteca:
- abrir o terminal linux
- bash createVideoteca10607.sh
- será necessario confirmar a eliminação de pastas e ficheiros (3 no total) 

* o script pode ser corrido em qualquer path
* em anexo segue um ficheiro com a estrutura de pastas da videoteca (videotecaStructure)