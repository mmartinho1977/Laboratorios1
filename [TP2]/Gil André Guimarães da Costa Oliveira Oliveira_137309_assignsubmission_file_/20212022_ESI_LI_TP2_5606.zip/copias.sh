echo " Copia de segurança da pasta Videoteca_2021 "


zip -r Backup.zip Videoteca_2021/
