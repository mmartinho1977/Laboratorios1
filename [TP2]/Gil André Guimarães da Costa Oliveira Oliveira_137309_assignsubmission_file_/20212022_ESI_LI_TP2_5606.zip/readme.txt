README

Correr o Script com o nome script.sh , caso necessario dar permissoes atravez do comando chmod u+r+x script.sh

O ficheiro irá criar toda a estrutura de pastas da videoteca, catalogando por tipo de filme.

O ficheiro copias.sh irá criar uma copia de sgurança da pasta Videoteca_2021 com o nome Backup.zip


Para extrair o backup, usamos o ficheiro restauro.sh e os dados iram para a pasta Restauro.


Gil Oliveira 
5606
