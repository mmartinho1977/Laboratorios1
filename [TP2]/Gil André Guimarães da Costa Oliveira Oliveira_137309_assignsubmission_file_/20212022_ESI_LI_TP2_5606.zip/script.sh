mkdir -p Videoteca_2021/ 
cd Videoteca_2021/
mkdir -p Action/"Doctor Strange in the Multiverse of Madness - 2022"
cd Action/"Doctor Strange in the Multiverse of Madness - 2022"
echo "Plot unknown. Sequel to the 2016 Marvel film 'Doctor Strange'.
Rating : not define" > "Doctor Strange in the Multiverse of Madness - 2022".txt
cd ..
cd ..
mkdir -p Adventure/"No Time to Die - 2021"
cd Adventure/"No Time to Die - 2021"
echo "James Bond has left active service. His peace is short-lived when Felix Leiter, an old 
friend from the CIA,turns up asking for help, leading Bond onto the trail of a mysterious 
villain armed with dangerous new technology. 
Rating: 7.4
" > "No Time to Die - 2021".txt
cd ..
cd ..
mkdir -p Drama/"The Last Letter from Your Lover - 2021"
cd Drama/"The Last Letter from Your Lover - 2021"
echo "A pair of interwoven stories set in the past and present follow an ambitious journalist 
determined to solve the mystery of a forbidden love affair at the center of a trove of secret 
love letters from 1965. 
Rating: 6.7" > "The Last Letter from Your Lover - 2021".txt
cd ..
cd ..
mkdir -p Horror/"Last Night in Soho - 2021"
cd Horror/"Last Night in Soho - 2021"
echo "An aspiring fashion designer is mysteriously able to enter the 1960s where she encounters a
dazzling wannabe singer. But the glamour is not all it appears to be and the dreams of the past 
start to crack and splinter into something darker.
Rating: 7.2" > "Last Night in Soho - 2021".txt
cd ..
cd ..
bash .\"copias.sh"

