## É necessário extrair os ficheiros!

#Para ser possível correr o script é necessário ter a pasta "Filmes" que se encontra na pasta "Lab", que contém o conteúdo de cada filme.

#É necessário mudar o caminho das pastas consoante a preferência do utilizador do script. Ex: este script cria as pastas dentro da pasta Lab

#É possível adicionar mais filmes, mas é necessário adicionar no script e mover os respetivos filmes

#O script cria as categorias e imprime as mesmas de maneira a ser possível navegar na consola e ver as informações de cada filme
