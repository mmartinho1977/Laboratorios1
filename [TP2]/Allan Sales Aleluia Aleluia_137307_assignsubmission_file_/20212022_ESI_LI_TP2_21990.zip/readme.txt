Requisitos para funcionamento da script:

- Os arquivos precisam estar todos na mesma pasta, mas não importa qual a pasta.
- É necessário digitar como a script informa, caso contrário pode apresentar erro.
- É fundamental ter instalado os pacotes da extenção .zip(para fazer isso digite o seguinte comando no terminal: "sudo apt-get install zip unzip").


Em caso de erro por digitação incorreta, deverá seguir os seguintes passos:

1º)Será necessário cancelar a execução da script(Crtl+C) e deletar a pasta videoteca.
2º)Executar novamente a script.