Para descompactar as scripts, deve ser executada a script "CriaDiretório.sh

Para isso, utilizamos o terminal, levamos o terminal até o local onde se encontra a script e depois executamos a script com o comando "bash" seguido do nome da script.


Ex.:

cd Desktop
bash CriaDiretório.sh


Depois basta seguir os passos indicados no terminal e está o diretório descompactado.

Na pasta "Fantasy" que foi criada dentro do diretório, existe um ficheiro com informação sobre uma série televisiva.
Cada pasta criada no diretório, quando o catálogo de filmes crescer, terá vários ficheiros, um para cada filme/ série.
