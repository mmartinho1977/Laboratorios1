#! /bin/sh #executa a script da forma Bourne Shell

	#Script
echo "====ELIMINAR FICHEIROS====" #Escreve na consola o conteúdo entre aspas

echo "Insira o caminho:"
read caminho #Lê o que o utilizador escreve na consola e aramzena numa variável
clear #Limpa a consola

cd #Leva a script à raíz do disco

cd $caminho #Leva a script ao caminho especificado na variável caminho
echo "O caminho $caminho inclui os seguintes items. Qual o ficheiro que pretende eliminar?"
ls #Lista os conteúdos do diretório
read eliminar

rm  $eliminar #Elimina o ficheiro de acordo com o especificdo dentro da variável eliminar

echo "Ficheiro apagado com sucessso!"




