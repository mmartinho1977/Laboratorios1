#! /bin/sh #executa a script da forma Bourne Shell

	#Script
echo "====COMPACTAR FICHEIRO====" #Escreve na consola o conteúdo entre aspas

cd #Leva a script à raíz do disco

echo "Insira o caminho onde se enconrea o arquivo a compactar."
read caminhoZip #Lê o que o utilizador escreve na consola e aramzena numa variável

echo "Insira o nome do arquivo a compactar."
read arquivo

echo "Insira o nome do ficheiro compactado incluíndo <.zip> no final (ex: Script.zip)"
read nomeZip

cd $caminhoZip #Leva a shell até ao caminho espceificado na variável

zip -r $nomeZip $arquivo #Compacta o arquivo especificado na variável "arquivo" e atribui o nome especificado na variável "nomeZip" ao ficheiro gerado

echo "O ficheiro compactado enontra-se em: $caminhoZip"
