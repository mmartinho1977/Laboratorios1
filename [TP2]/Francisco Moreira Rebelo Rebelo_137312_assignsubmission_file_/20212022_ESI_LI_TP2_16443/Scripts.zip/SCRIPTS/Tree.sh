#! /bin/sh #executa a script da forma Bourne Shell

	#Script
echo "====MOSTRAR UMA ÁRVORE DO CONTEÚDO DO DIRETŔORIO====" #Escreve na consola o conteúdo entre aspas

echo "Insira o caminho do diretório."
read caminhoDir #Lê o que o utilizador escreve na consola e aramzena numa variável

sudo apt-get install tree

tree -a $caminhoDir
