É necessário que todos os filmes com a os arquivos dir, sin e star sejam previamente criados para o funcionamento correto da script

Os filmes precisam estar dentro da pasta "Videoteca"

1º Na script, foram criadas Categorias para os filmes com o mkdir.
2º Entrei na videoteca e movi todos os filmes para sua respectiva categoria com o mv.
3º Foram criados para cada filme um arquivo info.txt que concatena as informaçoes previamente criadas.
4º O menu para navegar entre as categorias e os filmes foi feito com laços de repetiçao while.

Para zipar e descompactar uma pasta, basta instalar o pacote com o comando: apt-get install zip, executar o comando zip ou unzip junto da pasta desejada.zip.


