#!bin/bash
mkdir filmes # cria pasta filmes
cd filmes #entra na pasta filmes 
mkdir categoria_aventura #cria pasta categoria_aventura
cd categoria_aventura #entra na pasta categoria_aventura
mkdir velocidade_furiosa #cria pasta velocidade_furiosa
cd velocidade_furiosa
touch velocidade_furiosa.txt
cd velocidade_furiosa.txt
echo "Resumo"
echo"Brian O' Conner é um policial que se infiltra no submundo dos rachas
 de rua para investigar uma série de furtos.
 Enquanto tenta ganhar o respeito e a confiança do líder Dom Toretto,
 ele corre o risco de ser mascarado."
cd # permite entrar no disco c onde consta as diretorias todas
cd filmes # permite entrar na diretoria filmes
cd categoria_aventura
mkdir Venom
cd Venom
touch Venom.txt
cd Venom.txt
echo "Resumo"
echo "O jornalista Eddie Brock desenvolve força e poder sobre-humanos quando
o seu corpo funde-se com o alienígena Venom.
Dominado pela raiva, Venom tenta controlar as novas e perogosas habilidades
de Eddie." 
cd
cd filmes  # entra na pasta filmes 
mkdir categoria_comedia # cria pasta categoria_comedia
cd categoria_comedia
mkdir As_panteras
cd As_panteras
touch As_panteras.txt
cd As_panteras.txt
echo "Resumo"
echo"Elena,trata-se de uma ciêntista brilhante,inventa Calisto, fonte de
energia sustentável revolucionária. Quando a sua criação acaba nas mãos
erradas, ela pede ajuda da Panteras para evitar que o projeto seja usado
como uma arma de destruíção em massa."
cd
cd filmes
cd categoria_comedia
mkdir Deadpool
cd Deadpool
touch Deadpool.txt
cd Deadpool.txt
echo " Resumo"
echo " Wade wilson é um ex-combatente especial que passou a trabalhar como 
mercenário. O seu mundo é destruído quando um ciêntista maligno o tortura e 
o desfigura completamente. Esta experiência brutal transforma wade em 
Deadpool, que ganha poderes especiais de cura e uma força aprimorada. 
com a ajuda de aliados poderes e um senso de humor mais deslocado e cínico
do que nunca, o irreverente anti-heroi usa habilidades e métodos violentos 
para se vingar do homem que quase acabou com a sua vida."
cd
cd filmes 
mkdir categoria_drama
cd categoria_drama 
mkdir gravidade
cd gravidade 
touch gravidade.txt
cd gravidade.txt
echo "Resumo"
echo "Dra. Ryan Stone e o astronauta MaTT Kwalsky trabalham juntos para 
sobreviver depois deum acidente os deixar à deriva no espaço,sem ligação
com a Terra e a esperança de Vida."
cd
cd filmes 
cd categoria_drama
mkdir troia 
cd troia
touch troia.txt
cd troia.txt
echo "Resumo"
echo "É um filme que conta a história da batalha entre reinos antigos de
Troia e Esparta. Durante uma visita ao reino de Esparta, Menelau, o principe
Troiano Paris apaixona-se pela esposa do rei, Helena e leva-a de volta
para Troia. O irmão de Menelau, o rei Agamenon, que já havia derrotado todos
os exércitos na Grécia, encontra o pretexto que faltava para declarar gerra
contra Troia, o único reino que o impede de controlar o Mar Egeu."
cd
cd filmes 
mkdir categoria_fantasia
cd categoria_fantasia
mkdir homem_aranha
cd homem_aranha
touch homem_aranha.txt
cd homem_aranha.txt
echo "Resumo"
echo " Depois de se ter picado por uma aranha genéticamente modificada, numa
demonstração ciêntifica, o jovem Nerd Peter ganha poderes. Incialmente ele
pretende usá-los para ganhar dinheiro, adotandoo nome de Homem Aranha. Porém
ao presenciar o assaninato do seu tio, sente-se culpado, e decide usar os 
seus poderes para enfrentar o mal, tendo como  primeiro desafio vencer o 
psicótico Duende Verde."
cd
cd filmes
cd categoria_fantasia
mkdir luca
cd luca 
touch luca.txt
cd luca.txt
echo " Resumo"
echo "Luca vive aventuras com seu novo melhor amigo, mas a diversão é
ameaçada por um segredo, o seu amigo é um monstro marinho de outro mundo que
coabita abaixo da superfície da água."
