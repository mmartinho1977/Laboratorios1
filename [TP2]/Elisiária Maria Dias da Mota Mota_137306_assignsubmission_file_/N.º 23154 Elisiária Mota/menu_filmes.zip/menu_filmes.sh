#!/bin/bash
echo "*********************************************************************"
echo "IPCA- Instituto Politécnico do Cávado e do Ave
Departamento de Técnologias de Computação e Informação
Engenharia de Sistemas Informáticos
Labotarórios de Informática/Pós-Laboral"
echo "             " # mostra linha em branco
echo "TP2  Ano letivo:2021/2022" # mostra a mensagem  
echo -n "Nome do Aluno:" # mostra o nome do usuário na linha anterior
whoami  # exibe informação do usuário 
echo -n "Número de Aluno:23154" # exibe a mensagem escrita 
echo " "
echo "*********************************************************************"
echo "  "   #adiciona linha sem preenchimento
echo -n "Versão da pesquisa:" 
date +"Ano: %Y, Mês: %m, Dia: %d" # mostra a data 
echo "                                                                     "
echo "*********************************************************************"
echo "                                                                "
cd filmes  #permite entrar no diretório filmes 
echo "1- MENU DE FILMES                                               "
echo " "
ls # exibe as sub-diretorias existentes na diretoria filmes 
echo " " #adiciona linha em branco 
echo "**********************************************************************
Categoria Aventura"
echo "__________________"  # exibe a  mensagem ______
cd categoria_aventura   # entrar na sub-diretoria de filmes categoria aventura
echo " "
cd velocidade_furiosa   # permite entrar no filme velocidade furiosa
echo -n "velocidade Furiosa"
cat velocidade_furiosa.txt  # exibe o conteúdo do filme velocidade furiosa
echo "  "
cd .. # permite voltar à diretoria  categoria aventura
cd Venom
echo -n "Venom"
cat Venom.txt # exibe o conteúdo do filme Venom
echo " "
echo "**********************************************************************
Categoria Comédia"
echo "_________________"
cd ../../.. # volta três diretorias para trás
cd filmes/categoria_comedia # exibe a  sub-diretoria comédia 
echo " "
echo "As panteras"
cd As_panteras # entra no filme As panteras 
cat As_panteras.txt  # exibe o conteúdo do filme As panteras
echo "   " 
echo "Deadpool" # exibe o nome do filme Deadpool 
cd .. # para entrar no filme tenho que andar para trás uma diretoria
cd Deadpool # permite entrar no filme Deadpool 
cat Deapool.txt # exibe o conteúde Deadpool
echo "   "
echo "************************************************************************
Categoria Drama"
echo "_______________"
cd ../../..
cd filmes/categoria_drama
echo "    "
echo "Gravidade"
cd gravidade
cat gravidade.txt
echo "   "
echo "Troia"
cd ..
cd troia
cat troia.txt
echo " "
echo "************************************************************************
Categoria Fantasia"
echo "__________________"
cd ../../..
cd filmes/categoria_fantasia
echo " "
echo "Homem Aranha"
cd homem_aranha
cat homem_aranha.txt 
echo "  "
echo "  " 
echo "luca"
cd ..
cd luca 
cat luca.txt
echo "*********************************************************************"
echo "  "
echo "Sub-Diretorias existentes na diretoria filmes"
echo "_____________________________________________"
echo " "
cd 
cd filmes 
ls -l  #   exibe as sub-dietorias  existente na diretoria filmes 
echo " "
echo "*********************************************************************"
echo " "
echo "Últimas duas linhas do resumo do filme Velocidade Furiosa"
echo " "
cd categoria_aventura 
cd velocidade_furiosa 
tail -2 velocidade_furiosa.txt #exibe as duas últimas linhas do resumo
echo "  " 
echo "*********************************************************************"
echo " "
echo "Número de Linhas no resumo velocidade furiosa"
cd 
cd filmes 
cd categoria_aventura
cd velocidade_furiosa
echo " "  
wc -l velocidade_furiosa.txt 
echo " "
echo "********************************************************************"
echo "  "
echo " Número de palavras existente no resumo Velociade Furiosa"
echo " "
wc -w velocidade_furiosa.txt
echo " "
echo "********************************************************************"
echo " "
echo " Número de carateres existentes no resumo Velocidade Furiosa"
echo " "
wc -m velocidade_furiosa.txt
echo " "
echo "********************************************************************"
echo " "
echo "Conteúdo do Resumo velocidade furiosa"
echo "_____________________________________"
echo " "
cat velocidade_furiosa.txt
echo " "
echo "********************************************************************"
echo " " 
echo "Conteúdo do Resumo Velocidade Furiosa em Maiúsculas"
echo "___________________________________________________"
echo " "
cat velocidade_furiosa.txt | tr a-z A-Z
echo " " 
echo "********************************************************************"
echo " " 
echo "Últimas duas linhas das seis existentes no resumo velocidade furiosa" 
echo " ___________________________________________________________________"
cat -n velocidade_furiosa.txt | head -6 | tail -2
echo " "
echo "*********************************************************************"
echo " "
echo "Quantidade de palavras na diretoria:"
echo "____________________________________"
ls /usr/bin/ | wc -w 
echo " " 
echo "*********************************************************************"
echo " "
echo "Criação do ficheiro count.txt com a contagem de palavras na diretoria" 
echo "__________________________________________________________"
echo " "
ls /usr/bin/ |wc -w > count.txt
ls
echo " "
echo "*********************************************************************"
echo " " 
echo "Excluir o ficheiro count.txt"
echo "_________________________" 
echo " "
rm -r count.txt
ls
echo " "
echo "********************************Fim***********************************"
echo "  "


