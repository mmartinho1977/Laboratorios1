##################################################################################################
#                                                                                                #
#______LESI_PL____Laboratórios__de__Informática________Ricardo__Araújo_________Aluno 9576___     #
#                                                                                                #
##################################################################################################   
#
#
#
#
#
#     Para executar este ficheiro é necessário no terminal dar permissão 
#     com a script " chmod +x Trabalho_2.sh " 
#
#     Em seguida temos de fazer correr no terminal o ficheiro .sh com a script " ./Trabalho_2.sh "
#
#
#     Ao executar vai criar pastas com o comando "mkdir" e indicando as diretorias criou-se a 
#     estrutura da nossa videoteca que está estrutura em 4 tipos de filmes. 
#     Dentro de cada categoria de filme encontramos pastas com os nomes de varios filmes e 
#     dentro de cada pasta de um filme encontramos um ficheiro .txt com as caracteristicas e
#     um breve resumo desse mesmo filme. 
#		                                                                     
#     Vai ser apagada uma pasta de um filme 	
#     Depois de criada a estrutura vai executar a listagem das pastas e vai mover uma pasta para 
#     outra categoria de filme. 
#     
#     Fazemos a zipagem da pasta através do comando zip -r 
#     Para fazer o unzip da pasta Videoteca apresento uma condição if, ou seja, se estiver criada 
#     a pasta Videoteca zipada fazer o unzip dessa mesma pasta.
#
#
#
#
#########################################      FIM      ###########################################
#
#










