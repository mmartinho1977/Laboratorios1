# Diogo Gomes Silva 23893

cd ~/Documentos/ 
zip -r Videoteca.zip Videoteca #Cria um arquivo zip com a Pasta Videoteca e o seu conteudo dentro
rm -r Videoteca #Elimina a pasta videoteca que sobrou e que não foi zipada
