# Diogo Gomes Silva 23893

cd ~/Documentos/ 
cd Videoteca
ls 
cd Ação 
ls 
cd Fury
ls 
cat Summary.txt
cat cast.txt
cat Review.txt
cd .. 
cd 2Fast2Furious
ls 
cd .. 
cd Chappie
ls
cd .. 
cd .. 

sleep 2
cd Drama
ls
cd 1917
ls
cd .. 
cd AmericanSniper
ls
cd .. 
cd Dunkirk
ls
cd .. 
cd ..

sleep 2
cd Comédia
ls
cd BadBoys
ls
cd .. 
cd BayWatch
ls
cd .. 
cd JojoRabbit
ls
cd .. 
cd JumanjiWelcomeToTheJungle
ls
cd .. 
cd .. 

sleep 2
cd FicçãoCientifica
ls
cd Elysium
ls
cd .. 
cd Irobot
ls
cd .. 
cd TheHUngerGames
ls
cd .. 
cd ..

