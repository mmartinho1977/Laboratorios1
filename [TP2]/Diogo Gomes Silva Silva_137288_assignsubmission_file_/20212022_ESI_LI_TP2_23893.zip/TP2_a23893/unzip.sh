# Diogo Gomes Silva 23893

cd ~/Documentos/ 
unzip Videoteca.zip #Dá unzip do arquivo zip criado com a outra script e coloca a pasta videoteca e o seu conteudo no local escolhido em cima
rm Videoteca.zip #Elimina a pasta zipada da videoteca

