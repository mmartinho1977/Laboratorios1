#! /bin/bash

nano Videoteca/Categorias/Acao/John_Wick/Avaliacao.txt #abre pagina de alteração do conteudo do ficheiro Avaliacao.txt do filme John_Wick
