#! /bin/bash

nano Videoteca/Categorias/Acao/John_Wick/Sinopse.txt #abre pagina de alteração do conteudo do ficheiro Sinopse.txt do filme John_Wick
