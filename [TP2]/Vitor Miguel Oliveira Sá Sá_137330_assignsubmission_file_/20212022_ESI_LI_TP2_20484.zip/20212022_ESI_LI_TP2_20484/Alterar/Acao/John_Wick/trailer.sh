#! /bin/bash

nano Videoteca/Categorias/Acao/John_Wick/Trailer.txt #abre pagina de alteração do conteudo do ficheiro Trailer.txt do filme John_Wick
