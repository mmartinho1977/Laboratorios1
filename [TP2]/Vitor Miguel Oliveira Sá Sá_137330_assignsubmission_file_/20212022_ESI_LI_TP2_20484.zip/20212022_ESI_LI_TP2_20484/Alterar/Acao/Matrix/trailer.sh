#! /bin/bash

nano Videoteca/Categorias/Acao/Matrix/Trailer.txt #abre pagina de alteração do conteudo do ficheiro Trailer.txt do filme Matrix
