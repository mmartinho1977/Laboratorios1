#! /bin/bash

nano Videoteca/Categorias/Acao/Matrix/Reviews.txt #abre pagina de alteração do conteudo do ficheiro Reviews.txt do filme Matrix
