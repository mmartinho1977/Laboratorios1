#! /bin/bash

nano Videoteca/Categorias/Acao/Matrix/Cast.txt #abre pagina de alteração do conteudo do ficheiro Cast.txt do filme Matrix
