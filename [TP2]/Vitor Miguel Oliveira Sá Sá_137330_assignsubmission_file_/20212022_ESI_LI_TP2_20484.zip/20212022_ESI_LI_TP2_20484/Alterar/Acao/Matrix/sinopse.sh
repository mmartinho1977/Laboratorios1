#! /bin/bash

nano Videoteca/Categorias/Acao/Matrix/Sinopse.txt #abre pagina de alteração do conteudo do ficheiro Sinopse.txt do filme Matrix
