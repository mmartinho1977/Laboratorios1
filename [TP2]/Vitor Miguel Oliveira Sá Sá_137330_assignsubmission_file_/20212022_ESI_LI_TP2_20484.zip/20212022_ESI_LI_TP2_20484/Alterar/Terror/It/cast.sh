#! /bin/bash

nano Videoteca/Categorias/Terror/It/Cast.txt #abre pagina de alteração do conteudo do ficheiro Cast.txt do filme It
