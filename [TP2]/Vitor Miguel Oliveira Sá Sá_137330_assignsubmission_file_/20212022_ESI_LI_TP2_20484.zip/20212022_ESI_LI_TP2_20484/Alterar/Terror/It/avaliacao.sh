#! /bin/bash

nano Videoteca/Categorias/Terror/It/Avaliacao.txt #abre pagina de alteração do conteudo do ficheiro Avaliacao.txt do filme It
