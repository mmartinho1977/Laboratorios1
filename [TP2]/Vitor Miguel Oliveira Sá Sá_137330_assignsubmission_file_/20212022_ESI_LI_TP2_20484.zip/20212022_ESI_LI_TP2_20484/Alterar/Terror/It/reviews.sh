#! /bin/bash

nano Videoteca/Categorias/Terror/It/Reviews.txt #abre pagina de alteração do conteudo do ficheiro Reviews.txt do filme It
