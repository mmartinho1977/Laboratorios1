#! /bin/bash

nano Videoteca/Categorias/Terror/It/Trailer.txt #abre pagina de alteração do conteudo do ficheiro Trailer.txt do filme It
