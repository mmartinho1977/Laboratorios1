#! /bin/bash

nano Videoteca/Categorias/Terror/A_Quiet_Place/Sinopse.txt #abre pagina de alteração do conteudo do ficheiro Sinopse.txt do filme A_Quiet_Place
