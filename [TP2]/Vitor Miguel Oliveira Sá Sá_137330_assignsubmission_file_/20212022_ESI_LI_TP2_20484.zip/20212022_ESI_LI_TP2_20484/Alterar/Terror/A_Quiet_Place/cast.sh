#! /bin/bash

nano Videoteca/Categorias/Terror/A_Quiet_Place/Cast.txt #abre pagina de alteração do conteudo do ficheiro Cast.txt do filme A_Quiet_Place
