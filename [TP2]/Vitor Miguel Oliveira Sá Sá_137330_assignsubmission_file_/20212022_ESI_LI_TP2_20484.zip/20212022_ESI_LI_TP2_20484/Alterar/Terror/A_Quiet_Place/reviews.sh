#! /bin/bash

nano Videoteca/Categorias/Terror/A_Quiet_Place/Reviews.txt #abre pagina de alteração do conteudo do ficheiro Reviews.txt do filme A_Quiet_Place
