#! /bin/bash

nano Videoteca/Categorias/Guerra/Hacksaw_Ridge/Avaliacao.txt #abre pagina de alteração do conteudo do ficheiro Avaliacao.txt do filme Hacksaw_Ridge
