#! /bin/bash

nano Videoteca/Categorias/Guerra/Hacksaw_Ridge/Sinopse.txt #abre pagina de alteração do conteudo do ficheiro Sinopse.txt do filme Hacksaw_Ridge
