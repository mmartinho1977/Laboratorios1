#! /bin/bash

nano Videoteca/Categorias/Guerra/Hacksaw_Ridge/Reviews.txt #abre pagina de alteração do conteudo do ficheiro Reviews.txt do filme Hacksaw_Ridge
