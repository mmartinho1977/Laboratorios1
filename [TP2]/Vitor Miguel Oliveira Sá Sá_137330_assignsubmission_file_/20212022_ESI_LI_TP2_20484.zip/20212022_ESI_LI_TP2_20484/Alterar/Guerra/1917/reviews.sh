#! /bin/bash

nano Videoteca/Categorias/Guerra/1917/Reviews.txt #abre pagina de alteração do conteudo do ficheiro Reviews.txt do filme 1917
