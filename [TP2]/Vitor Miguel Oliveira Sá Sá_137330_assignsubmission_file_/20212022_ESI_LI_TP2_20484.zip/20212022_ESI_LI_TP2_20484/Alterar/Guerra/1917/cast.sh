#! /bin/bash

nano Videoteca/Categorias/Guerra/1917/Cast.txt #abre pagina de alteração do conteudo do ficheiro Cast.txt do filme 1917
