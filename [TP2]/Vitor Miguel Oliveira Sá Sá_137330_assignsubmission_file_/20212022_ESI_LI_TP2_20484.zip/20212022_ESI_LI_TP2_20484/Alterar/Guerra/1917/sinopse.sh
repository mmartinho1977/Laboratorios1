#! /bin/bash

nano Videoteca/Categorias/Guerra/1917/Sinopse.txt #abre pagina de alteração do conteudo do ficheiro Sinopse.txt do filme 1917
