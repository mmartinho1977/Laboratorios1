#! /bin/bash

unzip 20212022_ESI_LI_TP2_20484.zip
