Para dar unzip ao ficheiro utilize o script "unzip.sh"
Para criar as pastas e ficheiros dos varios filmes, categorias... use o script "diretivas.sh"

Dentro da pasta "Alterar" vai encontrar 1 pasta para cada categoria, e dentro 1 outra pasta para cada filme com 1 script para a alteração individual de cada ficheiro do respetivo filme.

Podera também usar o script zip para zipar novamente o trabalho.