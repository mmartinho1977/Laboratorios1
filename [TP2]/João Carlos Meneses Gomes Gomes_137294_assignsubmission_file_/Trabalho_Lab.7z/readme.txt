Passo 1: Colocar a script (ficheiros.sh) no Ambiente de trabalho.
Passo 2: Abrir o terminal e entrar no Ambiente de trabalho para dar direitos de escrita leitura e execução á script (Chmod 777 ficheiros.sh)
Passo 3: No unzip alterar a diretoria para /home/martamartinho/Documentos ou Documents por exemplo
Passo 4: O mesmo se aplica para o find alterar a diretoria /home/martamartinho/Desktop ou Area de Trabalho/Videoteca para realizar a contagem do numero de ficheiros que existem dentro da diretoria Videoteca
