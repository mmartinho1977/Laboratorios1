Este ficheiro destina-se a ajudar a criar a tua propria lista de filmes que tenhas em casa para um ficheiro para mais tarde saberes os filmes que tens ou até mesmo quantos tens.
No terminal executar: ./moviemain.sh
Depois de aberto o terminal premir:
C-se desejar criar uma pasta para as varias librarias(por exemplo a libraria Home que corresponde a casa);
    1-para avançar para que libraria gostava de aceder uma lista(por exemplo temos a lista Favourite que é a lista dos favoritos);
    2-criar uma lista(por exemplo temos a lista Favourite que é a lista dos favoritos);
    3-mostrar listas(pastas) que existam;
    4-retroceder colocando o nome da pasta que gostaria de aceder;
    5-criar um ficheiro dando um nome;

depois de criado os ficheiros:
6- para aceder ao ficheiro e altera-lo eliminando ou acrescentados filmes á lista;
G- listar por genero;
N- listar por nome;
H- contar os filmes da nossa lista;
Z- para comprimir o nosso ficheiro.extensão
