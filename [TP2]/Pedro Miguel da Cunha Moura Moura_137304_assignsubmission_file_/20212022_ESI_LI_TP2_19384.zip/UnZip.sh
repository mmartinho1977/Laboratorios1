#! /bin/bash


unzip Videoteca.zip #EXTRAIR O CONTEUDO DO FICHEIRO Videoteca.zip


