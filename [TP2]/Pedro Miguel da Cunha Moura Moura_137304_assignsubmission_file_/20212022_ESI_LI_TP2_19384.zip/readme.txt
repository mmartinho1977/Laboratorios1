Executar o script UnZip.sh
Caso dê algum problema relacionado com acesso negado deve executar o comando abaixo:
chmod +x UnZip.sh

De seguida executar o script Videoteca.sh
Caso dê algum problema relacionado com acesso negado deve executar o comando abaixo:
chmod +x Videoteca.sh

Navegar na lista de opções existentes.
