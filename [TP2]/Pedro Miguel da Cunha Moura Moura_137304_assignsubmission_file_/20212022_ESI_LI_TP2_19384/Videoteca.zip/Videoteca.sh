#! /bin/bash



 #variavel
 OPT_=0


#################################################
#VERIFICA SE PASTA VIDEOTECA EXISTE. SE NÃO EXISTIR CRIA
function pasta_videoteca(){
clear
 if  [[ ! -d "Videoteca" ]]
 then
 	mkdir "Videoteca" 
 fi
}

#################################################

#################################################
 #FUNCÃO PARA SELECÇÃO DO MENU PRINCIPAL
function menu_principal(){
 clear
 echo "*****************************************"
 echo "************ [  VIDEOTECA  ] ************"
 echo "*****************************************"
 echo "**** Escolha qual a opção pretendida ****"
 echo "*****************************************"
 echo "1 - Inserir"
 echo "2 - Listar"
 echo "3 - Outras Opções"
 echo "4 - Sair"
 echo "*****************************************"
 echo "*****************************************"


 OPT_=0
 
 until [ "$OPT_" == "" ] 
 do
 
 read -p "Opção: " OPT_ #Recebe a opção
 
 if [ $OPT_ == 4 ] #caso selecione a opção 4, termina o programa
 then
 	exit 0
 	
 elif [ $OPT_ == 1 ] #caso selecione a opção 1 vai para a função menu_Inserir
      then menu_Inserir
           menu_principal
 
 elif [ $OPT_ == 2 ] #caso selecione a opção 2 vai para a função menu_consultar
      then menu_consultar
           menu_principal

 elif [ $OPT_ == 3 ] #caso selecione a opção 3 vai para a função menu_opcoes
      then menu_opcoes
           menu_principal
           
 else
  	menu_principal	
 fi

 done
 
 }
 ###############################################


 #FUNCÃO PARA ESCOLHER A CATEGORIA DE INSERÇÃO
 function menu_Inserir(){

 menu_categoria_ "INSERIR" 
 
  #variaveis
  AJ_CAT="" 
  CAT_FILME=""
  
  until [ "$CAT_FILME" != "" ]
   do
    read -p "Opção: " CAT_FILME
 
    AJ_CAT=""
 
  if [ $CAT_FILME == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO
  then
 	AJ_CAT="Ação"
  elif [ $CAT_FILME == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA
  then
  	AJ_CAT="Aventura"
  elif [ $CAT_FILME == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA
  then
  	AJ_CAT="Drama"
  elif [ $CAT_FILME == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA
  then
  	AJ_CAT="Comédia" 	
  elif [ $CAT_FILME == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO
  then
  	AJ_CAT="Romântico"
  elif [ $CAT_FILME == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR
  then
  	AJ_CAT="Terror"
  elif [ $CAT_FILME == 9 ]
  then
  	menu_principal
  else	 
   	menu_Inserir	 	  	 	  	
  fi
	
 done
 
 
 
 if [ "$AJ_CAT" != "" ]
 then
 
  echo "****** [ $AJ_CAT ] ******"
  read -p "Nome: " INS_NOME	#NOME DO FILME
  read -p "Ano: " INS_ANO	#ANO DO FILME	
  read -p "Resumo: " INS_RESU	#RESUMO DO FILME
	 
  echo "*****************************************"
  
  verifica_se_existe_ "Videoteca/$AJ_CAT" #CHAMA A FUNÇÃO, CASO A PASTA REFERENTE À CATEGORIA, NÃO EXISTA, CRIA.
  
 
  if  [ -f "Videoteca/$AJ_CAT/$INS_NOME" ] #VERIFICA SE O FILME JA EXISTE.
  then
 	  read -p "O Filme $INS_NOME já existe. Prima S para substituir. " R_

	  if [[ "$R_" == "s"  ||  "$R_" == "S" ]] #CASO ESCOLHA A OPÇÃO "S". 
	  then
		
		#SUBTITUI O CONTEUDO DO FICHEIRO JA EXISTENTE
		echo "Nome: $INS_NOME" > "Videoteca/$AJ_CAT/$INS_NOME" 
		echo "Ano: $INS_ANO" >> "Videoteca/$AJ_CAT/$INS_NOME"
		echo "Resumo: $INS_RESU" >> "Videoteca/$AJ_CAT/$INS_NOME"
			
	  fi  
  else
  	#CRIA O FICHEIRO
  	touch "Videoteca/$AJ_CAT/$INS_NOME"

	echo "Nome: $INS_NOME" >> "Videoteca/$AJ_CAT/$INS_NOME"
	echo "Ano: $INS_ANO" >> "Videoteca/$AJ_CAT/$INS_NOME"
	echo "Resumo: $INS_RESU" >> "Videoteca/$AJ_CAT/$INS_NOME"
  fi
 
    
  echo "*****************************************"

  echo " "
  read -p "Prima S para continuar a inserir. " R_
 
  if [[ "$R_" == "s"  ||  "$R_" == "S" ]] #CASO ESCOLHA A OPÇÃO "S". VOLTA AO INICIO DA FUNÇÃO
  then
	menu_Inserir
  fi 
	 
	 
 fi
 
 }
 
 
 
 #FUNCÃO PARA CONSULTAR CATEGORIAS JA INSERIDAS
 function menu_consultar(){

 menu_categoria_ "LISTAR" 
 
  #variaveis
  AJ_CAT="" 
  CAT_FILME=""
  
  until [ "$CAT_FILME" != "" ]
   do
    read -p "Opção: " CAT_FILME
 
    AJ_CAT=""
 
  if [ $CAT_FILME == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO
  then
 	AJ_CAT="Ação"
  elif [ $CAT_FILME == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA
  then
  	AJ_CAT="Aventura"
  elif [ $CAT_FILME == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA
  then
  	AJ_CAT="Drama"
  elif [ $CAT_FILME == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA
  then
  	AJ_CAT="Comédia" 	
  elif [ $CAT_FILME == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO
  then
  	AJ_CAT="Romântico"
  elif [ $CAT_FILME == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR
  then
  	AJ_CAT="Terror"
  elif [ $CAT_FILME == 9 ]
  then
  	menu_principal
  else	 
   	menu_consultar	 	  	 	  	
  fi
	
 done
 
 
 
 if [ "$AJ_CAT" != "" ]
 then
 
  clear
 
  echo "************** [ $AJ_CAT ] **************"
  echo "*****************************************"
  echo " "	
  
  TOTAL=0
    	 
  if  [[ -d "Videoteca/$AJ_CAT" ]] #VERIFICA SE PASTA SELECIONADA NA CATEGORIA EXISTE
  then	
  	
	FICHEIROS=`ls "Videoteca/$AJ_CAT"` #Pesquisa o conteudo existente na pasta
	for FICHEIRO in "$FICHEIROS"
	
	do
	  echo "$FICHEIRO" #Lista o conteudo
	  
	  echo " "
	  echo "********** [ Total Filmes (`ls "Videoteca/$AJ_CAT" | wc -l `) ] **********"	#Com a opção | wc -l #Conta o total de ficheiros existentes na pasta
	done
  else
  	echo "********** [ Total Filmes (0) ] **********"			
  fi

  
  echo " "
  read -p "Prima S para continuar a consultar. " R_
 
  if [[ "$R_" == "s"  ||  "$R_" == "S" ]]
  then
	menu_consultar
  fi  
	 
 fi
 
 }
 
###############################################

#FUNCÃO PARA ABRIR / ALTERAR / APAGAR / MOVER / EDITAR
 function menu_opcoes(){
  clear
  echo "*****************************************"
  echo "********* [ OUTRAS OPÇÕES ] *************"
  echo "*****************************************"
  echo "**** Escolha a categoria pretendida  ****"
  echo "*****************************************"
  echo "1 - Abrir"
  echo "2 - Editar"
  echo "3 - Alterar Nome"
  echo "4 - Mover"
  echo "5 - Apagar"
  echo "*****************************************"
  echo "****      9 - Menu Principal         ****"
  echo "*****************************************"
 
 OPCAO_=""
 until [ "$OPCAO_" != "" ]
   do
    read -p "Opção: " OPCAO_
 
  if [ $OPCAO_ == 1 ] #OPÇÃO 1, direciona para a função menu_abrir
  then
 	menu_abrir
 	menu_opcoes
  elif [ $OPCAO_ == 2 ] #OPÇÃO 2, direciona para a função menu_editar
  then
  	menu_editar
  	menu_opcoes
  elif [ $OPCAO_ == 3 ] #OPÇÃO 3, direciona para a função menu_alterar_nome
  then
  	menu_alterar_nome
  	menu_opcoes	
  elif [ $OPCAO_ == 4 ] #OPÇÃO 4, direciona para a função menu_mover
  then
  	menu_mover
  	menu_opcoes
  elif [ $OPCAO_ == 5 ] #OPÇÃO 5, direciona para a função menu_apagar
  then
  	menu_apagar
  	menu_opcoes 	
  elif [ $OPCAO_ == 9 ] #OPÇÃO 5, direciona para o menu principal
  then
  	menu_principal
  else	 
   	menu_opcoes	 #Qualquer outra opção, mantem o mesmo menu	  	 	  	
  fi
	
 done
 
 
 
 }
###############################################
 
#FUNCÃO PARA abrir/visualizar o conteudo do documento
 function menu_abrir(){
 
  menu_categoria_ "ABRIR" 
 
  #variaveis
  AJ_CAT="" 
  CAT_FILME=""
  
  until [ "$CAT_FILME" != "" ]
   do
    read -p "Opção: " CAT_FILME
 
    AJ_CAT=""
 
  if [ $CAT_FILME == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO
  then
 	AJ_CAT="Ação"
  elif [ $CAT_FILME == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA
  then
  	AJ_CAT="Aventura"
  elif [ $CAT_FILME == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA
  then
  	AJ_CAT="Drama"
  elif [ $CAT_FILME == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA
  then
  	AJ_CAT="Comédia" 	
  elif [ $CAT_FILME == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO
  then
  	AJ_CAT="Romântico"
  elif [ $CAT_FILME == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR
  then
  	AJ_CAT="Terror"
  
  elif [ $CAT_FILME == 7 ]
  then
  	menu_opcoes	
  elif [ $CAT_FILME == 9 ]
  then
  	menu_principal
  else	 
   	menu_abrir	 	  	 	  	
  fi
	
 done
 
 
 if [ "$AJ_CAT" != "" ]
 then
 
	conteudo_ $AJ_CAT #VAI PARA A FUNÇÃO QUE MOSTRA O CONTEUDO DA CATEGORIA SELECIONADA
	
	if [ $AJ_CONTEUDO_ == 1 ]  #CASO TENHA CONTEUDO
	then
		read -p "Opção: " A_
		
		re='^[0-9]+$' 		#VERIFCAR SE A RESPOSTA É NUMERICO
		if [[ $A_ =~ $re ]] 	#VERIFCAR SE A RESPOSTA É NUMERICO
		then
			if [ $A_ -le $(( n-1 )) ]	#CASO A OPÇÃO SEJA INFERIOR OU IGUAL AO NUMERO DE FILMES.		
			then	  
			 
	   			echo "*****************************************"	
	   			echo " "
	   			
	   			more "Videoteca/$AJ_CAT/"${FICHEIROS[$A_]}"" #MOSTRA CONTEUDO DO FILME SELECIONADO
	   			
	   			echo " "	
	   			echo "*****************************************"

	 	   		
	   		else
	   			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   			menu_abrir
	   		fi	 
		else
			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   		menu_abrir
		fi
	fi


  	echo " "	
  	read -p "Prima S para continuar abrir os filmes. " R_
 
  	if [[ "$R_" == "s"  ||  "$R_" == "S" ]]
  	then
		menu_abrir
  	fi  
	 
 fi
 
  
 }
 
############################################### 

#FUNCÃO PARA editar o conteudo do documento
 function menu_editar(){
 
  menu_categoria_ "EDITAR" 
 
  #variaveis
  AJ_CAT="" 
  CAT_FILME=""
  
  until [ "$CAT_FILME" != "" ]
   do
    read -p "Opção: " CAT_FILME
 
    AJ_CAT=""
 
  if [ $CAT_FILME == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO
  then
 	AJ_CAT="Ação"
  elif [ $CAT_FILME == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA
  then
  	AJ_CAT="Aventura"
  elif [ $CAT_FILME == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA
  then
  	AJ_CAT="Drama"
  elif [ $CAT_FILME == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA
  then
  	AJ_CAT="Comédia" 	
  elif [ $CAT_FILME == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO
  then
  	AJ_CAT="Romântico"
  elif [ $CAT_FILME == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR
  then
  	AJ_CAT="Terror"
  
  elif [ $CAT_FILME == 7 ]
  then
  	menu_opcoes	
  elif [ $CAT_FILME == 9 ]
  then
  	menu_principal
  else	 
   	menu_editar	 	  	 	  	
  fi
	
 done
 
 
 if [ "$AJ_CAT" != "" ]
 then
 
	conteudo_ $AJ_CAT #VAI PARA A FUNÇÃO QUE MOSTRA O CONTEUDO DA CATEGORIA SELECIONADA
	
	if [ $AJ_CONTEUDO_ == 1 ] #CASO TENHA CONTEUDO
	then
		read -p "Opção: " A_
		
		re='^[0-9]+$' 		#VERIFCAR SE A RESPOSTA É NUMERICO
		if [[ $A_ =~ $re ]] 	#VERIFCAR SE A RESPOSTA É NUMERICO
		then
			if [ $A_ -le $(( n-1 )) ] #CASO A OPÇÃO SEJA INFERIOR OU IGUAL AO NUMERO DE FILMES.	
			then	  
			 
	   			nano "Videoteca/$AJ_CAT/"${FICHEIROS[$A_]}"" #ABRE O FILME SELECIONADO, PERMITINDO EDITAR O CONTEUDO DO FICHEIRO

	   		 	
	   		
	   		else
	   			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   			menu_editar
	   		fi	 
		else
			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   		menu_editar
		fi
	fi


  	echo " "
  	read -p "Prima S para continuar editar o conteudo dos filmes. " R_
 
  	if [[ "$R_" == "s"  ||  "$R_" == "S" ]]
  	then
		menu_editar
  	fi  
	 
 fi
 
 
 
 }
 
############################################### 
 
#FUNCÃO PARA mudar o nome do arquivo
 function menu_alterar_nome(){
  
  menu_categoria_ "ALTERAR NOME" 
  
  #variaveis
  AJ_CAT="" 
  CAT_FILME=""
  
  until [ "$CAT_FILME" != "" ]
  do
    read -p "Opção: " CAT_FILME
 
    AJ_CAT=""
 
  if [ $CAT_FILME == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO
  then
 	AJ_CAT="Ação"
  elif [ $CAT_FILME == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA
  then
  	AJ_CAT="Aventura"
  elif [ $CAT_FILME == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA
  then
  	AJ_CAT="Drama"
  elif [ $CAT_FILME == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA
  then
  	AJ_CAT="Comédia" 	
  elif [ $CAT_FILME == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO
  then
  	AJ_CAT="Romântico"
  elif [ $CAT_FILME == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR
  then
  	AJ_CAT="Terror"
  
  elif [ $CAT_FILME == 7 ]
  then
  	menu_opcoes	
  elif [ $CAT_FILME == 9 ]
  then
  	menu_principal
  else	 
   	menu_alterar_nome	 	  	 	  	
  fi
	
 done
 
 
 if [ "$AJ_CAT" != "" ]
 then
 
	conteudo_ $AJ_CAT #VAI PARA A FUNÇÃO QUE MOSTRA O CONTEUDO DA CATEGORIA SELECIONADA
	
	if [ $AJ_CONTEUDO_ == 1 ] #CASO TENHA CONTEUDO
	then
		read -p "Opção: " A_
		
		re='^[0-9]+$' 		#VERIFCAR SE A RESPOSTA É NUMERICO
		if [[ $A_ =~ $re ]] 	#VERIFCAR SE A RESPOSTA É NUMERICO
		then
			if [ $A_ -le $(( n-1 )) ] #CASO A OPÇÃO SEJA INFERIOR OU IGUAL AO NUMERO DE FILMES.
			then	   
	   			echo "*****************************************"	
	   			echo " "
	   			
	   			read -p "Novo nome: " NOVO_ #CAPTA O NOVO NOME PARA O FILME
	   		
	   			mv "Videoteca/$AJ_CAT/"${FICHEIROS[$A_]}"" "Videoteca/$AJ_CAT/$NOVO_" #ALTERAR NOME DO FILME
				
				echo " "
	   			echo "*****************************************"
	   		
	   		else
	   			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   			menu_alterar_nome
	   		fi	 
		else
			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   		menu_alterar_nome
		fi
	fi


  	echo " "
  	read -p "Prima S para continuar a alterar nome dos filmes. " R_
 
  	if [[ "$R_" == "s"  ||  "$R_" == "S" ]]
  	then
		menu_alterar_nome
  	fi  
	 
 fi
 
 }
 
############################################### 

############################################### 
 
#FUNCÃO PARA MOVER O ARQUIVO PARA OUTRA CATEGORIA
 function menu_mover(){
  
  menu_categoria_ "ORIGEM" 
  
  #variaveis
  AJ_CAT="" 
  CAT_FILME=""
  
  until [ "$CAT_FILME" != "" ]
  do
    read -p "Opção: " CAT_FILME
 
    AJ_CAT=""
 
  if [ $CAT_FILME == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO
  then
 	AJ_CAT="Ação"
  elif [ $CAT_FILME == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA
  then
  	AJ_CAT="Aventura"
  elif [ $CAT_FILME == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA
  then
  	AJ_CAT="Drama"
  elif [ $CAT_FILME == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA
  then
  	AJ_CAT="Comédia" 	
  elif [ $CAT_FILME == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO
  then
  	AJ_CAT="Romântico"
  elif [ $CAT_FILME == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR
  then
  	AJ_CAT="Terror"
  
  elif [ $CAT_FILME == 7 ]
  then
  	menu_opcoes	
  elif [ $CAT_FILME == 9 ]
  then
  	menu_principal
  else	 
   	menu_mover	 	  	 	  	
  fi
	
 done
 
 
 if [ "$AJ_CAT" != "" ]
 then
 
	conteudo_ $AJ_CAT #VAI PARA A FUNÇÃO QUE MOSTRA O CONTEUDO DA CATEGORIA SELECIONADA
	
	if [ $AJ_CONTEUDO_ == 1 ] #CASO TENHA CONTEUDO
	then
		read -p "Opção: " A_
		
		re='^[0-9]+$' 		#VERIFCAR SE A RESPOSTA É NUMERICO
		if [[ $A_ =~ $re ]] 	#VERIFCAR SE A RESPOSTA É NUMERICO
		then
			if [ $A_ -le $(( n-1 )) ]	 #CASO A OPÇÃO SEJA INFERIOR OU IGUAL AO NUMERO DE FILMES.	
			then	   
	   		
				  menu_categoria_ "DESTINO" 
				  
				  #variaveis
				  AJ_CAT_2="" 
				  CAT_FILME_2=""
				  
				  until [ "$CAT_FILME_2" != "" ]
				  do
				    read -p "Opção: " CAT_FILME_2
				 
				    AJ_CAT_2=""
				 
				  if [ $CAT_FILME_2 == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO COMO DESTINO
				  then
				 	AJ_CAT_2="Ação"
				  elif [ $CAT_FILME_2 == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA COMO DESTINO
				  then
				  	AJ_CAT_2="Aventura"
				  elif [ $CAT_FILME_2 == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA COMO DESTINO
				  then
				  	AJ_CAT_2="Drama"
				  elif [ $CAT_FILME_2 == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA COMO DESTINO
				  then
				  	AJ_CAT_2="Comédia" 	
				  elif [ $CAT_FILME_2 == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO COMO DESTINO
				  then
				  	AJ_CAT_2="Romântico"
				  elif [ $CAT_FILME_2 == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR COMO DESTINO
				  then
				  	AJ_CAT_2="Terror"
	 	  	 	  else
	 	  	 	  	CAT_FILME_2=""	
				  fi
					
				 done
				 
				 verifica_se_existe_ "Videoteca/$AJ_CAT_2/" #CASO A CATEGORIA DE DESTINO NÃO EXISTA, CRIA A PASTA.
				 
	   			 mv "Videoteca/$AJ_CAT/"${FICHEIROS[$A_]}"" "Videoteca/$AJ_CAT_2/"${FICHEIROS[$A_]}"" #MOVER FILME
	   		
	   		 	
	   		
	   		else
	   			echo " "
	   			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   			menu_mover
	   		fi	 
		else
			echo " "
			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   		menu_mover
		fi
	fi


  	echo " "
  	read -p "Prima S para mover mais filmes. " R_
 
  	if [[ "$R_" == "s"  ||  "$R_" == "S" ]]
  	then
		menu_mover
  	fi  
	 
 fi
 
 }
 
############################################### 

#FUNCÃO PARA APAGAR O FILME
 function menu_apagar(){
  
  menu_categoria_ "APAGAR" 
  
  #variaveis
  AJ_CAT="" 
  CAT_FILME=""
  
  until [ "$CAT_FILME" != "" ]
  do
    read -p "Opção: " CAT_FILME
 
    AJ_CAT=""
 
  if [ $CAT_FILME == 1 ] #OPÇÃO 1, ESCOLHE A CATEGORIA ACÃO
  then
 	AJ_CAT="Ação"
  elif [ $CAT_FILME == 2 ] #OPÇÃO 2, ESCOLHE A CATEGORIA AVENTURA
  then
  	AJ_CAT="Aventura"
  elif [ $CAT_FILME == 3 ] #OPÇÃO 3, ESCOLHE A CATEGORIA DRAMA
  then
  	AJ_CAT="Drama"
  elif [ $CAT_FILME == 4 ] #OPÇÃO 4, ESCOLHE A CATEGORIA COMEDIA
  then
  	AJ_CAT="Comédia" 	
  elif [ $CAT_FILME == 5 ] #OPÇÃO 5, ESCOLHE A CATEGORIA ROMANTICO
  then
  	AJ_CAT="Romântico"
  elif [ $CAT_FILME == 6 ] #OPÇÃO 6, ESCOLHE A CATEGORIA TERROR
  then
  	AJ_CAT="Terror"
  
  elif [ $CAT_FILME == 7 ]
  then
  	menu_opcoes	
  elif [ $CAT_FILME == 9 ]
  then
  	menu_principal
  else	 
   	menu_apagar	 	  	 	  	
  fi
	
 done
 
 
 if [ "$AJ_CAT" != "" ]
 then
 
	conteudo_ $AJ_CAT #VAI PARA A FUNÇÃO QUE MOSTRA O CONTEUDO DA CATEGORIA SELECIONADA
	
	if [ $AJ_CONTEUDO_ == 1 ] #CASO TENHA CONTEUDO
	then
		read -p "Opção: " A_
		
		re='^[0-9]+$' 		#VERIFCAR SE A RESPOSTA É NUMERICO
		if [[ $A_ =~ $re ]]	#VERIFCAR SE A RESPOSTA É NUMERICO 
		then
			if [ $A_ -le $(( n-1 )) ]	#CASO A OPÇÃO SEJA INFERIOR OU IGUAL AO NUMERO DE FILMES.	
			then	   

	   			rm "Videoteca/$AJ_CAT/"${FICHEIROS[$A_]}"" #ELIMINAR FILME

	   		else	
	   			echo " "
	   			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   			menu_apagar
	   		fi	 
		else
			echo " "
			read -p "Opção não encontrada. Qualquer tecla para continuar. "	
	   		menu_apagar
		fi
	fi


  	echo " "
  	read -p "Prima S para continuar a eliminar filmes. " R_
 
  	if [[ "$R_" == "s"  ||  "$R_" == "S" ]]
  	then
		menu_apagar
  	fi  
	 
 fi
 
 }
 
############################################### 



#################################################
#Procura os filmes existentes nas pastas
function conteudo_(){
clear

echo "************** [ $1 ] **************"
echo "*****************************************"
echo " "  	
    	 
if  [[ -d "Videoteca/$1" ]] #VERIFICA SE PASTA SELECIONADA NA CATEGORIA EXISTE
then	

	n=0
	FICHEIROS=( $( ls  Videoteca/$1 ) ) #CONTEUDO DA PASTA
	for FICHEIRO in "${!FICHEIROS[@]}" 
	do

	  echo "$FICHEIRO - ${FICHEIROS[$FICHEIRO]}" #LISTA FICHEIROS COM INDICE DE FORMA A USAR ESSE MESMO INDICE PARA SELEÇÃO DO FILME.
	  	
	  n=$(( n+1 ))	
	done
	
 	echo " "
	echo "********** [ Total Filmes ( $n ) ] **********"	#TOTAL DE FILMES ENCONTRADOS

	AJ_CONTEUDO_=1 #SE ENCONTROU
else
	AJ_CONTEUDO_=0 #SE NÃO TEM CONTEUDO
	echo " "
	echo "********** [ Total Filmes ( 0 ) ] **********"					
fi


}


##################################################
#FUNÇÃO ONDE LISTA AS CATEGORIAS EXISTENTES
function menu_categoria_()
{

  clear
  echo "*****************************************"
  echo "************ [ $1 ] ***********"
  echo "*****************************************"
  echo "**** Escolha a categoria pretendida  ****"
  echo "*****************************************"
  echo "1 - Ação"
  echo "2 - Aventura"
  echo "3 - Drama"
  echo "4 - Comédia"
  echo "5 - Romântico"
  echo "6 - Terror"
  
  #apenas mostra a opção 7 se for algumas destas opções Abrir/Editar/Alterar/Mover/Apagar
  if [[ "$1" == "ABRIR"  ||  "$1" == "EDITAR"  ||  "$1" == "ALTERAR NOME"  ||  "$1" == "MOVER"  ||  "$1" == "APAGAR"  ]] 
  then
  	echo "*****************************************"  
  	echo "****      7 - Menu Anterior          ****"
  fi
  
  echo "*****************************************"
  echo "****      9 - Menu Principal         ****"
  echo "*****************************************"
  
}


##################################################
function verifica_se_existe_()
{


  if  [[ ! -d $1 ]] #VERIFICA SE PASTA SELECIONADA NA CATEGORIA NÃO EXISTE
  then
  	mkdir $1 #CRIA PASTA
  	
  fi
  
    
}

 
###############################################
#EXECUÇÃO PRINCIPAL#
 pasta_videoteca
 menu_principal
##############################################





