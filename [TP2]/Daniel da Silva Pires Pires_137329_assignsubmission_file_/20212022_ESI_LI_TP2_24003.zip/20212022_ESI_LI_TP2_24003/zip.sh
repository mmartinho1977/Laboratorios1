sudo apt install zip unzip  # instala o zip mais recente do Linux
zip -r Backup.zip Videoteca/ #comprime o ficheiro
