sudo apt install zip unzip  # instala o zip mais recente do Linux
unzip Backup.zip -d Backup # descomprime o ficheiro videoteca.zip
