Execute a script como um progama
