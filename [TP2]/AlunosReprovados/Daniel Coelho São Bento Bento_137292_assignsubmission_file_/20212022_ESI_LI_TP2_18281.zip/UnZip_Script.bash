#!/bin/bash

zip <nome_zip>.zip #descomprimir uma pasta