Funções do scrip a executar:
-Criação da pasta Videoteca e dentro dela as pastas: Horror,Action,Comedy,Romance;
-Criação dos ficheiro Plot.txt, Rating.txt, Cast.txt dentro da pasta de cada filme;
-Criação de uma cópia, colocando assim este filme nas duas categorias;
-Criação do zip de toda a diretoria Videoteca;
-Efetuar o unzip para a pasta Videos;
-Criação de pasta Info, onde foram criados 2 ficheiros, um para contar o numero de pastas na diretoria e o outro para descobrir os filmes com cotação igual a 9;



Execução da Script encontrando-se no Desktop.
1ª - Abrir Terminal e escrever o seguinte comando "cd Desktop", acedendo assim ao Desktop;
2º - Irá ser necessário alterar o caminho para o utilizador em questão, então desta forma escrevemos o seguinte comando "nano ScriptVideoteca.sh" e na linha 37 e 43 alteramos o nome "hugobarbosa" para o utilizador da maquina local. Para salvar pressionar CRTL X seguido de Y para sair e gravar;
3º - Escrever o seguinte comando "bash ./ScriptVideoteca.sh;
4º - Videoteca criada com sucesso, de salientar que foi efetuado um unzip para a pasta Videos;



