
#! /bin/bash

#zipar recursivamente o diretório videoteca

zip -r videoteca.zip videoteca
