#! /bin/bash

#Dar unzip à videoteca 

unzip videoteca.zip
