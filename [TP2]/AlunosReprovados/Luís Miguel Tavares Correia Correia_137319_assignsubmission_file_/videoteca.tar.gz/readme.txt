1. Descompactar os ficheiros para o diretorio "Desktop".
2. Abrir o terminal e situar-se no diretorio "Desktop".
3. Inserir o comando "chmod +x Videoteca.sh" para ter permissão de executar o scritp Videoteca.sh"
4. Executar o script: insira o comando < ./Videoteca.sh >
5. O diretorio "Videoteca" foi criado com as respetivas pastas, sub-pastas e ficheiros.
