Trabalho realizado por João Morais
Numero: 17214

Para executar a script unzip.sh deverá abrir o terminal e colocar este comando chmod +x unzip.sh;

Para descomprimir a directoria Videoteca, basta executar a script unzip.sh,
esta irá dar unzip da pasta Videoteca na directoria Desktop/.

Para executar as scripts, terá de executar primeiramente alguns comandos para conseguir executar
as scripts, estes comandos terá de dos fazer no terminal, sendo eles:
chmod +x script.sh
chmod +x texto.sh
chmod +x remover.sh
chmod +x info.sh
chmod +x zip.sh

Após isso apenas tem de executar as scripts para isso, abrir o terminal e fazer ./"script" por
exemplo ./script.sh;

A script.sh irá criar a directoria Videoteca com as suas subdirectorias, após isso deverá ser
executado a script texto.sh que irá adicionar texto com informação dos filmes ,a script remover.sh
irá remover ficheiros, e a script info.sh irá mostrar informação sobre alguns ficheiros txt com
informações acerca dos filmes, como quantidade de linhas, quantidade de palavras, etc;
   
Para dar zip novamente basta executar a script zip.sh que irá criar um zip da pasta Videoteca na directoria Desktop/.
