#!/bin/bash

clear
cd
cd Desktop/

	unzip Videoteca.zip #Faz unzip da Videoteca
	echo "Ficherio descomprimido";

