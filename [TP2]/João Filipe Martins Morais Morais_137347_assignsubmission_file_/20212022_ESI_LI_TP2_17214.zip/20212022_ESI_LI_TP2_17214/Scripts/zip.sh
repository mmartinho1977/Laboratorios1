#!/bin/bash

clear
cd
cd Desktop/

	zip -r Videoteca.zip Videoteca/ #Faz zip da Videoteca e o -r faz com que o faça recursivamente, ou seja faz zip de todas as diretorias e subdirectorias da Videoteca
	echo "Ficherio comprimido";


