Antes da primeira execução:

Colocar os ficheiros:
    Acao.sh
    Aventura.sh
    Comedia.sh
    Crime.sh
    Desporto.sh
    Romance.sh
    Terror.sh
    linux.sh

    na Home directory (acessível através do comando cd ~)

Instalar as seguintes ferramentas:

 - jq (sudo apt install jq)
 - curl (sudo apt install curl)

Todos os comandos do ficheiro linux.sh e Acao.sh estão comentados.

Aviso: A API do IMDB tem um limite aproximado de 100 pedidos por dia.
Durante a execução do ficheiro linux.sh, irão ser criados outros ficheiros.



