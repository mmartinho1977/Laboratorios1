#!/bin/bash

sudo apt install zip unzip  # para instalar o zip mais recente do Linux no seu computador

unzip Backup.zip -d ~/Desktop # descomprime o ficheiro, neste caso o ficheiro videoteca.zip
