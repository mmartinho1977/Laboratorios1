#!/bin/bash

sudo apt install zip unzip  # para instalar o zip mais recente do Linux no seu computador

zip -r Backup.zip Videoteca/ #comprime a Pasta que pretende, neste caso comprimimos a pasta"Videoteca"
