Para executar a script execute ./trabalho.sh, se não tiver permissões utilize o comando Chmod +x nomedoprograma. 
Assim vai criar uma pasta chamada "videoteca" com várias pastas dentro dela.
