cd ~/Documents/
unzip Videoteca.zip #Descomprimir a pasta Videoteca
rm Videoteca.zip #Eliminar a pasta Videoteca que está comprimida








