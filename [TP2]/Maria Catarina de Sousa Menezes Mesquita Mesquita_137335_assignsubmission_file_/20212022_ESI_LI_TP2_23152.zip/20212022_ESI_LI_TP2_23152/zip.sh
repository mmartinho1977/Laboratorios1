cd ~/Documents/
zip -r Videoteca.zip Videoteca #Comprimir a pasta Videoteca
rm -r Videoteca #Eliminar a pasta Videoteca que não está comprimida








