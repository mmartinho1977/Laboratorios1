Descomprimir a pasta 20212022_ESI_LI_TP2_23152 na pasta ~/Documents
Abrir a linha de comandos e executar o comando: sh ~/Documents/20212022_ESI_LI_TP2_23152/script.sh
Para comprimir a pasta Videoteca executar o comando: sh ~/Documents/20212022_ESI_LI_TP2_23152/zip.sh
Para descomprimir a pasta Videoteca executar o comando: sh ~/Documents/20212022_ESI_LI_TP2_23152/unzip.sh
