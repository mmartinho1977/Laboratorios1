#! /bin/bash

# Curso - Engenharia em Sistemas Informáticos
# Cadeira - Laboratório de Informática
# TP2 - Trabalho Prático 2
# Docente - Marta Martinho
# Turma - ESI(PL)
# Ano Letivo - 2021/2022 - 1º Semestre

#Descompactar o arquivo em ZIP.	

	unzip ViodeTeca.zip	
