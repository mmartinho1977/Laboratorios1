Projeto TP2 - Pedro Meneses a17551

Este projeto deve estar localizado no ambiente de trabalho ou num local de fácil acesso visto a script só ter caminhos referenciados dentro do próprio ficheiro e irá compilar onde estiver.

Para executar a script deve: 

- Abrir o Terminal
- Navegar até a pasta onde contem este readme
- executar o comando  chmod +x script.sh & ./script.sh

A parte do chmod serve para dar permissões.

A script foi feita num todo de forma a fazer todos os pontos do enunciado.

Irei enviar um ficheiro VideotecaFinal.zip que será igual ao resultado final de quando a script.sh for executada. ( requerido no enunciado ) 