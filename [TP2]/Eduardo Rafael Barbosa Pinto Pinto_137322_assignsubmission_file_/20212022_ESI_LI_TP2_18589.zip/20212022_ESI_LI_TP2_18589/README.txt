Como começar a usar
1. Coloque o ficheiro 20212022_ESI_LI_TP2_18589.zip em qualquer pasta.
2. Abra o seu emulador shell favorito.
3. Escreva o comando "cd caminho/do/ficheiro/Menu.sh" para a pasta onde está o fcheiro Menu.sh sem as aspas.
4. Agora escreva "chmod +x Menu.sh" sem as aspas para fazer o script executável.
5. Por final escreva "./Menu.sh" para o executar.
