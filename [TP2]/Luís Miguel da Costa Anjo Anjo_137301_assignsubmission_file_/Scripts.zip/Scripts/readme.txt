Para Execução das Scripts:
É indiferente onde estará a pasta Scripts

Primeiro deverá executar a script zip.sh:
Irá aparecer para selecionar se pretende descompactar ou comprimir o zip, escolha a opção 2.
Depois de descomprir a diretoria irá aparecer o diretório Videoteca_1.

Depois deverá executar a script criar.sh:
Ao executar ela irá criar o diretório Videoteca com todos os seus sub-diretórios(Categorias).
Irá mover ficheiros e verificará se é tudo movido em condições e todas as pastas ficam criadas.
Depois irá aparecer para escolher um diretório para ver o numero de arquivos existente e pastas
Poderá escrever "Videoteca" e aparecerá o valor.

E para finalizar o script irá aparecer se pretende excluir a pasta Videoteca_1 para ficar só com a Videoteca.
