clear
echo "--------------------------------------"
echo "---- Backup dos Filmes ---------------"
echo "--------------------------------------"
echo ""
echo ""
cd ..
zip -r "./backups/backup-$(date +%F).zip" movies # compacta o ficheiros na pasta movies e cria um ficheiro zip na 
# pasta de backups com a data do sistema
cd scripts
echo ""
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
cd ..
bash ./menu.sh

