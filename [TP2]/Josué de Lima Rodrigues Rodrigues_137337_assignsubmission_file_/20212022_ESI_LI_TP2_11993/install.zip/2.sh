clear
echo "--------------------------------------"
echo "---- Filmes Encontrados --------------"
echo "--------------------------------------"
echo ""
echo ""
find ../movies -iname "*$1*" # pesquisa ficheiros na pasta movies
echo "" # parametro -iname para ser case-insensitive
echo "" # *$1* parametro $1 é o primeiro parametro da bash * para 
#que a pesquisa seja realizada em qualquer parte do nome do ficheiro.
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
cd ..
bash ./menu.sh
