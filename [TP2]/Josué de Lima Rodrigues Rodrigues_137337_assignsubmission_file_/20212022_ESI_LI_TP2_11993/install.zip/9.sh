clear
echo "--------------------------------------"
echo "-- Marcar como Lido ------------------"
echo "--------------------------------------"
echo ""
echo "Ano do Filme:"
read ano # input do ano do filme a marcar como lido
echo ""
echo "Nome do Filme"
read nome # input do nome do filme a marcar como lido
echo ""
echo ""
cd ..
if test -f ./movies/"${ano} - ${nome}"; then # Verifica se o ficheiro existe
   echo "Status:1" | tee -a ./movies/"${ano} - ${nome}" # se existir a ficha do filme. adiciona Status:1 no fim do ficheiro
else # a utilização do pipe | para poder realizar duas operações separadas na mesma linha de comandos
   echo "----------------------------------"
   echo "Filme inexistente na base de dados"
   echo "----------------------------------"
fi
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
bash ./menu.sh

