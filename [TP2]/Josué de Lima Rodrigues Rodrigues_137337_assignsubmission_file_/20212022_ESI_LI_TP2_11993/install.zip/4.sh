clear
echo "--------------------------------------"
echo "---- Filmes Encontrados --------------"
echo "--------------------------------------"
echo ""
echo ""
grep -li "Genre:"$1 ../movies/*; # para procurar dentro dos ficheiros na 
# pasta movies o texto Genre:<genero de filme>
# parametro -li para ser case-insensitive
# $1 = primeiro paramentro da bash 
echo ""
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
cd ..
bash ./menu.sh

