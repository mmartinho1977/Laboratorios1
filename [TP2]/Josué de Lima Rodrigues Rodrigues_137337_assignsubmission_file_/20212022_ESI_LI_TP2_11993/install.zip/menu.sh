clear # limpar o ecran
echo "--------------------------------------"
echo "VIDEOTECA DO ALUNO : 19553"
echo "MENU"
echo ""
echo "1  - Listar Filmes"
echo "2  - Procurar Filme"
echo "3  - Procurar Por Actor/Atriz"
echo "4  - Procurar Por Genero"
echo "5  - Procurar Por Ano"
echo "6  - Procurar Nao Vistos"
echo "7  - Adicionar Filme"
echo "8  - Remover Filme"
echo "9  - Marcar como visto"
echo "10 - Ver Ficha do Filme"
echo "11 - Editar Ficha do Filme"
echo "12 - Backup"
echo "13 - Sobre"
echo "14 - Voltar para o sistema Operativo"
echo ""
echo "- Escolha uma opcao ------------------"
echo ""
echo ""
echo "Escolha a opcao"
read op pa # pedir input ao utilizador
echo "--"
echo $op # mostrar primeiro input ( opção ) apenas para depuração
echo $pa # mostrar segundo input ( texto ) apenas para depuração
echo "--"
if [ $op -ge 1 ] && [ $op -lt 15 ] # verificar se opção está entre 1 e a 14
then  # deverá ser igual ou superior a 1 -ge e ( && )  inferior a 5 -lt
   cd scripts # abrir pasta de scripts
   bash "./${op}.sh" $pa # executar script correspondente á opção escolhida
else
   bash ./menu.sh # executar bash menu
fi
