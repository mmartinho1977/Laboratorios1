clear
echo "--------------------------------------"
echo "-- Remover Filme ---------------------"
echo "--------------------------------------"
echo ""
echo "Ano do Filme:"
read ano # input do ano do filme a remover 
echo ""
echo "Nome do Filme"
read nome # input do nome do filme a remover
echo ""
echo ""
cd ..
if test -f ./movies/"${ano} - ${nome}"; then # condição para verificar se o ficheiro existe
   rm ./movies/"${ano} - ${nome}"   # se existir remove o ficheiro
else # condição se o filme não existir
   echo "----------------------------------"
   echo "Filme inexistente na base de dados"
   echo "----------------------------------"
fi 
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
bash ./menu.sh

