clear
echo "--------------------------------------"
echo "-- Mostrar Conteudo do Filme ---------"
echo "--------------------------------------"
echo ""
echo "Ano do Filme:"
read ano # input do ano do filme a listar
echo ""
echo "Nome do Filme"
read nome # input do nome do filme a listar
echo ""
echo ""
cd ..
if test -f ./movies/"${ano} - ${nome}"; then # verificação se o filme (ficheiro) existe 
   echo ""
   echo "Tamanho da Ficha - Word Count:"
   wc ./movies/"${ano} - ${nome}" # conta o numero de palavras na ficha 
   echo ""
   echo "Ficha:"
   cat ./movies/"${ano} - ${nome}" # mostra o conteudo do ficheiro
else
   echo "----------------------------------"
   echo "Filme inexistente na base de dados"
   echo "----------------------------------"
fi
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
bash ./menu.sh


