clear
echo "--------------------------------------"
echo "-- Filme novo ------------------------"
echo "--------------------------------------"
echo ""
echo "Ano do Filme:"
read ano # input pelo utilizador do ano para a criação do novo filme
echo ""
echo "Nome do Filme"
read nome # input do nome do novo filme
echo ""
echo ""
cd .. # navegação para a pasta anterior
cp Template ./movies/"${ano} - ${nome}" # copia do ficheiro de template para o nome do filme
echo "- Clique enter para EDITAR A ficha do filme ---"
read op # para input do utilizador e fazer uma pausa antes de voltar editar
# a ficha do filme
nano ./movies/"${ano} - ${nome}"
echo ""
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
bash ./menu.sh


