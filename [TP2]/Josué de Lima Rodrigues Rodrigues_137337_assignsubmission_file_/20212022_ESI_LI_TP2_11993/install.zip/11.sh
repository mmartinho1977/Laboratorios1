clear
echo "--------------------------------------"
echo "-- Editar Filme ----------------------"
echo "--------------------------------------"
echo ""
echo "Ano do Filme:"
read ano # input do ano do filme a editar
echo ""
echo "Nome do Filme"
read nome # input do nome do filme a editar
echo ""
echo ""
cd ..
if test -f ./movies/"${ano} - ${nome}"; then # verifica de o ficheiro existe
   nano ./movies/"${ano} - ${nome}" # edita o ficheiro
else
   echo "----------------------------------"
   echo "Filme inexistente na base de dados"
   echo "----------------------------------"
fi
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
bash ./menu.sh

