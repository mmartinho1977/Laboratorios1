clear
echo "--------------------------------------"
echo "-- Listagem dos Filmes não vistos ----"
echo "--------------------------------------"
echo ""
echo ""
grep -iL "Status:1" ../movies/*; # para procurar dentro dos ficheiros na 
# pasta movies o texto Status:1 ( indica que o filme ja foi visto )
# $1 = primeiro paramentro da bash 
echo ""
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
cd ..
bash ./menu.sh

