clear
echo "--------------------------------------"
echo "---- Sobre o projeto -----------------"
echo "--------------------------------------"
echo ""
echo ""
sed -n 162,164p ../readme.txt # mostra o texto no ficheiro de readme.txt das linhas 162 até a 164
echo ""
echo ""
echo "- Clique enter para voltar ao menu ---"
read op # para input do utilizador e fazer uma pausa antes de voltar 
# ao menu
cd ..
bash ./menu.sh
