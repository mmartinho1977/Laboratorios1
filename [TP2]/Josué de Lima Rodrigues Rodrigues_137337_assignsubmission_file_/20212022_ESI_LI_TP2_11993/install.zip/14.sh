clear
echo "--------------------------------------"
echo "- Obrigado por utilizar a Videoteca --"
echo "--------------------------------------"
echo ""
echo ""

