clear
echo "--------------------------------------"
echo "---- Listagem dos Filmes -------------"
echo "--------------------------------------"
echo ""
echo ""
ls -x -1 ../movies # lista os ficheiros na pasta movies 
echo "" # paramento -x mostra informação apenas do nome
echo "" # paramentro -1 mostra em 1 coluna
echo "- Clique enter para voltar ao menu ---"
read op # pede input ao utilizador ( para fazer pausa e dar enter )
cd ..
bash ./menu.sh
