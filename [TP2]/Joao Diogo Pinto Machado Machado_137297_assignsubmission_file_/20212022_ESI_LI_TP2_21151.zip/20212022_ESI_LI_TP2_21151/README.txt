Executar a script bash "install.sh" na sua home directory( ~ ).

Se quer ver um ficheiro por completo, execute "cat localizacao do ficheiro".